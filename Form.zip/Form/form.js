// Form submission and modal logic for pickup form
const FORMSPREE_ENDPOINT = "https://formspree.io/f/movlblkl";

document.addEventListener("DOMContentLoaded", function() {
  const form = document.getElementById("pickupForm");
  const statusEl = document.getElementById("formStatus");
  const btn = document.getElementById("submitBtn");
  const alertSuccess = document.getElementById("alertSuccess");
  const alertError = document.getElementById("alertError");
  const thankYouModal = document.getElementById("thankYouModal");
  const closeModalBtn = document.getElementById("closeModalBtn");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    alertSuccess.classList.add("is-hidden");
    alertError.classList.add("is-hidden");
    statusEl.textContent = "";
    btn.disabled = true;
    btn.classList.add("is-loading");

    const required = ["fullName","street","city","state","postal","country","email","phone"];
    for (const name of required) {
      const el = form.elements[name];
      if (!el || !el.value.trim()) {
        statusEl.textContent = "Please complete all required fields.";
        statusEl.className = "status status-error";
        el && el.focus();
        btn.disabled = false;
        btn.classList.remove("is-loading");
        return;
      }
    }
    // Check consent checkbox
    const consentCheckbox = form.querySelector('input[type="checkbox"][required]');
    if (consentCheckbox && !consentCheckbox.checked) {
      statusEl.textContent = "Please confirm your details are correct.";
      statusEl.className = "status status-error";
      consentCheckbox.focus();
      btn.disabled = false;
      btn.classList.remove("is-loading");
      return;
    }

    const payload = {
      fullName: form.fullName.value.trim(),
      street: form.street.value.trim(),
      city: form.city.value.trim(),
      state: form.state.value.trim(),
      postal: form.postal.value.trim(),
      country: form.country.value.trim(),
      email: form.email.value.trim(),
      phone: form.phone.value.trim(),
      notes: form.notes.value.trim(),
      _gotcha: form._gotcha.value || ""
    };

    statusEl.textContent = "Submitting…";
    statusEl.className = "status";

    try {
      const resp = await fetch(FORMSPREE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(payload)
      });

      if (resp.ok) {
        form.reset();
        statusEl.textContent = "";
        // Show thank you modal
        thankYouModal.classList.remove("is-hidden");
        closeModalBtn.focus();
      } else {
        const data = await resp.json().catch(() => ({}));
        alertError.textContent = data?.error || "Error: Please try again.";
        alertError.classList.remove("is-hidden");
      }
    } catch (err) {
      alertError.textContent = "Network error. Please try again.";
      alertError.classList.remove("is-hidden");
    } finally {
      btn.disabled = false;
      btn.classList.remove("is-loading");
    }
  });

  // Modal close handler
  closeModalBtn.addEventListener("click", function() {
    thankYouModal.classList.add("is-hidden");
  });
});
